import { runTool } from "../tools";
import { fetchTimeout, appTokenHeader } from "../http";
import { GeminiStreamAccumulator, drainSSE } from "../stream";
import type { AskCtx, JarvisReply } from "./types";

// Gemini odrzuca niektóre pola JSON Schema (np. additionalProperties) — także
// w zagnieżdżonych obiektach/tablicach. Usuwamy je rekurencyjnie.
function sanitize(node: any): any {
  if (Array.isArray(node)) return node.map(sanitize);
  if (node && typeof node === "object") {
    const out: any = {};
    for (const [k, v] of Object.entries(node)) {
      if (k === "additionalProperties" || k === "$schema") continue;
      out[k] = sanitize(v);
    }
    return out;
  }
  return node;
}

function cleanSchema(schema: Record<string, unknown>): Record<string, unknown> | undefined {
  const props = (schema.properties as Record<string, unknown>) || {};
  if (Object.keys(props).length === 0) return undefined; // brak argumentów -> bez parameters
  return sanitize({
    type: "object",
    properties: props,
    required: (schema.required as string[]) || [],
  });
}

interface Part {
  text?: string;
  inlineData?: { mimeType: string; data: string };
  functionCall?: { name: string; args: Record<string, unknown> };
  functionResponse?: { name: string; response: { result: string } };
}
interface Content {
  role: "user" | "model";
  parts: Part[];
}

// Adapter Google Gemini (AI Studio) — format contents/parts + functionDeclarations.
export async function askGemini(ctx: AskCtx): Promise<JarvisReply> {
  // Bez proxy klucz idzie w URL — pusty/niepełny klucz daje mylący błąd Google
  // („Expected OAuth 2 access token"). Złap to od razu, z czytelnym komunikatem.
  if (!ctx.proxyUrl && !ctx.apiKey?.trim()) {
    throw new Error("Brak klucza Google Gemini (401). Wklej klucz w ⚙ → AI (Szybki start).");
  }
  const base = ctx.proxyUrl
    ? `${ctx.proxyUrl}/gemini?model=${ctx.model}`
    : `https://generativelanguage.googleapis.com/v1beta/models/${ctx.model}:generateContent?key=${ctx.apiKey.trim()}`;

  const functionDeclarations = ctx.tools.map((d) => ({
    name: d.name,
    description: d.description,
    parameters: cleanSchema(d.input_schema),
  }));

  const contents: Content[] = ctx.history.map((m) => ({
    role: m.role === "assistant" ? "model" : "user",
    parts: m.image
      ? [
          { inlineData: { mimeType: m.image.mediaType, data: m.image.data } } as Part,
          { text: m.content || "Opisz, co widzisz na zdjęciu." },
        ]
      : [{ text: m.content }],
  }));
  const used = new Set<string>();
  let inTok = 0;
  let outTok = 0;
  let guard = 0;
  // Strumieniujemy tylko BEZPOŚREDNIO (proxy /gemini mapuje na generateContent, nie SSE).
  let canStream = !!ctx.onToken && !ctx.proxyUrl;
  const headers = { "content-type": "application/json", ...(ctx.proxyUrl ? appTokenHeader() : {}) };
  const buildBody = (): any => {
    const reqBody: any = { systemInstruction: { parts: [{ text: ctx.system }] }, contents };
    if (functionDeclarations.length) reqBody.tools = [{ functionDeclarations }];
    return reqBody;
  };

  // Pełna odpowiedź — ścieżka klasyczna / fallback.
  const requestFull = async (): Promise<Part[]> => {
    const res = await fetchTimeout(base, { method: "POST", headers, body: JSON.stringify(buildBody()) }, 120000);
    const data = await res.json().catch(() => null);
    if (!res.ok) throw new Error(`${data?.error?.message || "Błąd API"} (${res.status})`);
    if (data.usageMetadata) { inTok += data.usageMetadata.promptTokenCount || 0; outTok += data.usageMetadata.candidatesTokenCount || 0; }
    return data.candidates?.[0]?.content?.parts || [];
  };

  // Strumieniowanie (SSE, tylko bezpośrednio) — tekst leci deltami; functionCall składamy.
  const streamUrl = `https://generativelanguage.googleapis.com/v1beta/models/${ctx.model}:streamGenerateContent?alt=sse&key=${ctx.apiKey.trim()}`;
  const requestStream = async (): Promise<Part[]> => {
    const res = await fetchTimeout(streamUrl, { method: "POST", headers, body: JSON.stringify(buildBody()) }, 120000);
    if (!res.ok) {
      const data = await res.json().catch(() => null);
      throw new Error(`${data?.error?.message || "Błąd API"} (${res.status})`);
    }
    const reader = res.body?.getReader();
    if (!reader) throw new Error("stream-unsupported");
    const dec = new TextDecoder();
    const acc = new GeminiStreamAccumulator();
    let buf = "";
    for (;;) {
      const { done, value } = await reader.read();
      if (done) break;
      buf += dec.decode(value, { stream: true });
      const { events, rest } = drainSSE(buf);
      buf = rest;
      for (const ev of events) { const delta = acc.push(ev); if (delta) ctx.onToken?.(delta); }
    }
    const tail = drainSSE(buf + "\n\n");
    for (const ev of tail.events) { const delta = acc.push(ev); if (delta) ctx.onToken?.(delta); }
    inTok += acc.usage.inputTokens; outTok += acc.usage.outputTokens;
    return [
      ...(acc.text ? [{ text: acc.text } as Part] : []),
      ...acc.calls().map((c) => ({ functionCall: { name: c.name, args: (c.args as Record<string, unknown>) || {} } }) as Part),
    ];
  };

  while (guard++ < 8) {
    let parts: Part[];
    try {
      parts = canStream ? await requestStream() : await requestFull();
    } catch (e) {
      const em = e instanceof Error ? e.message : String(e);
      if (canStream && !/timeout|abort|failed to fetch|load failed|network/i.test(em)) {
        canStream = false; guard--; continue; // hiccup strumienia → pełna odpowiedź
      }
      throw e;
    }
    contents.push({ role: "model", parts });

    const calls = parts.filter((p) => p.functionCall);
    if (calls.length) {
      const responseParts: Part[] = [];
      for (const c of calls) {
        const name = c.functionCall!.name;
        used.add(name);
        const out = await runTool(name, c.functionCall!.args || {});
        responseParts.push({ functionResponse: { name, response: { result: out } } });
      }
      contents.push({ role: "user", parts: responseParts });
      continue;
    }

    const text = parts
      .filter((p) => p.text)
      .map((p) => p.text)
      .join("")
      .trim();
    return { text: text || "…", tools: [...used], usage: { inputTokens: inTok, outputTokens: outTok } };
  }
  return { text: "Zapętliłem się przy realizacji zadania.", tools: [...used], usage: { inputTokens: inTok, outputTokens: outTok } };
}
